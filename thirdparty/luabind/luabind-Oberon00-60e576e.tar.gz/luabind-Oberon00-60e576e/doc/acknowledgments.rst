Acknowledgments
===============

Written by Daniel Wallin and Arvid Norberg. © Copyright 2003.
All rights reserved.

Evan Wies has contributed with thorough testing, countless bug reports
and feature ideas.

Many features and fixes of this fork come from `Ryan Pavlik's (rpavlik) fork`__
and from `Peter Colberg (fhoefling's fork)`__.

.. __: https://github.com/rpavlik/luabind/
.. __: https://github.com/fhoefling/luaponte/

Christian Neumüller (Oberon00) is the maintainer of `this fork`_.

.. _this fork: http://github.com/Oberon00/luabind/

A rather complete list of contributors can be found at
http://github.com/Oberon00/luabind/contributors.

This library was highly inspired by Dave Abrahams' Boost.Python_ library.

.. _Boost.Python: http://www.boost.org/libs/python